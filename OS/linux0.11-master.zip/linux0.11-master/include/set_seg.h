#ifndef SET_SEG_H
#define SET_SEG_H

#define _inline _forceinline

#endif